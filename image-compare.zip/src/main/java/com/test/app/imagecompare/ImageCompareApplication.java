package com.test.app.imagecompare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageCompareApplication {

    public static void main(String[] args) {
        SpringApplication.run(ImageCompareApplication.class, args);
    }

}
